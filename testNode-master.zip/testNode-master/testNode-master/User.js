import bcrypt from "bcryptjs"
import usersCollection from "../db"
import Loyalty from "./Loyalty"

class User {
  constructor(data, socket) {
    this.data = data
    this.errors = []

    /**
     * Il Socket del Client è necessario per inviare, finchè é connesso, aggiornamenti sul suo stato Loyalty
     * in modo di riuscire ad evitare che possa usuffruire dei bonus non meritati dopo la scadenza dell'anno.
     *
     * Per evitare di utilizzare i Socket si può effettuare un aggiornamento dello stato Loyalty ogni volta che il
     * Client esegue una richiesta.
     *
     * Un'alternativa ai Socket sono gli SSE (Server Sent Events).
     */
    this.socket = socket;
  }

  register() {
    // ...user data validation

    return new Promise((resolve, reject) => {
      if (!this.errors.length) {
        usersCollection
          .findOne({
            $or: [{ username: this.data.username }, { email: this.data.email }]
          })
          .then(user => {
            if (user) {
              if (user.username == this.data.username) this.errors.push("Username già in uso.")
              if (user.email == this.data.email) this.errors.push("Email già in uso.")
              return reject(this.errors)
            }

            const salt = bcrypt.genSaltSync(10)
            this.data.salt = salt;
            this.data.password = bcrypt.hashSync(this.data.password, salt)

            usersCollection
              .insertOne(this.data)
              .then(res => {
                this.data._id = res.insertedId

                // Start loyalty program (year 1)
                this.data.loyalty = new Loyalty(this.data, this.socket)

                resolve(this.data)
              })
              .catch(reject)
          })
      } else {
        reject(this.errors)
      }
    })
  }
}

export default User

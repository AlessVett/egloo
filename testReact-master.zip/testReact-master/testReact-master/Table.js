import { Component } from "react"
import './table.css';

class ComponentName extends Component {

  constructor(props) {
    super(props);
    this.state = {
      users: [
        {
          name: "Mario",
          surname: "Rossi",
          username: "mario.rossi",
          email: "mario.rossi@email.com",
          phone: "1234567890",
          address: "Via Roma 1",
          cap: "12345",
          city: "Roma",
          province: "RM",
          state: "Italia"
        },
        {
          name: "Luigi",
          surname: "Verdi",
          username: "luigi.verdi",
          email: "luigi.verdi@email.com",
          phone: "1234567890",
          address: "Via Verdi 1",
          cap: "12345",
          city: "Napoli",
          province: "NA",
          state: "Italia"
        },
        {
          name: "Giovanni",
          surname: "Bianchi",
          username: "giovanni.bianchi",
          email: "giovanni.bianchi@email.com",
          phone: "1234567890",
          address: "Via Rossi 1",
          cap: "12345",
          city: "Roma",
          province: "RM",
          state: "Italia"
        }
      ],
      sorting: {
        asc: [],
        desc: []
      },
      filters: {
        city: '',
        province: '',
        state: ''
      },
      filter: false
    }
  }



  handleSorting(e, filter) {
    let sorting = this.state.sorting;
    if (sorting.asc.includes(filter)) {
      delete sorting.asc[sorting.asc.indexOf(filter)];
      sorting.desc.push(filter);
    } else if (sorting.desc.includes(filter)) {
      delete sorting.desc[sorting.desc.indexOf(filter)];
    } else sorting.asc.push(filter);

    this.state.users.sort((a, b) => {

      for (const key of sorting.asc) {
        if (a[key] < b[key]) {
          return -1;
        }

        if (a[key] > b[key]) {
          return 1;
        }
      }

      for (const key of sorting.desc) {
        if (a[key] > b[key]) {
          return -1;
        }

        if (a[key] < b[key]) {
          return 1;
        }
      }

      return 0;
    });

    this.setState({sorting: sorting});
  }
  render() {
    return (
      <>
        <main className="table">
          <div className="filters">
            <div className={`filters-btn ${this.state.filter ? 'active' : ''}`} onClick={() => this.setState({filter: !this.state.filter})}>
              <i className="bi bi-sliders"></i>
            </div>
            <div className={`list ${this.state.filter ? 'active' : ''}`}>
              <div className="input" data-label="City:"><input type="text" onChange={($e) => {
                this.state.filters.city = $e.target.value.trim();
                this.setState({filters: this.state.filters});
              }}/></div>
              <div className="input" data-label="Province:"><input type="text" onChange={($e) => {
                this.state.filters.province = $e.target.value.trim();
                this.setState({filters: this.state.filters});
              }}/></div>
              <div className="input" data-label="State:"><input type="text" onChange={($e) => {
                this.state.filters.state = $e.target.value.trim();
                this.setState({filters: this.state.filters});
              }}/></div>
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th onClick={$event => this.handleSorting($event, 'name')}>
                  <div>
                    Name
                    <div className="sorting">
                      <i className={`bi bi-caret-up-fill asc ${this.state.sorting.asc.includes('name') ? 'active' : ''}`}></i>
                      <i className={`bi bi-caret-down-fill desc ${this.state.sorting.desc.includes('name') ? 'active' : ''}`}></i>
                    </div>
                  </div>
                </th>
                <th onClick={$event => this.handleSorting($event, 'surname')}>
                  <div>
                    Surname
                    <div className="sorting">
                      <i className={`bi bi-caret-up-fill asc ${this.state.sorting.asc.includes('surname') ? 'active' : ''}`}></i>
                      <i className={`bi bi-caret-down-fill desc ${this.state.sorting.desc.includes('surname') ? 'active' : ''}`}></i>
                    </div>
                  </div>
                </th>
                <th onClick={$event => this.handleSorting($event, 'username')}>
                  <div>
                    Username
                    <div className="sorting">
                      <i className={`bi bi-caret-up-fill asc ${this.state.sorting.asc.includes('username') ? 'active' : ''}`}></i>
                      <i className={`bi bi-caret-down-fill desc ${this.state.sorting.desc.includes('username') ? 'active' : ''}`}></i>
                    </div>
                  </div>
                </th>
                <th onClick={$event => this.handleSorting($event, 'email')}>
                  <div>
                    Email
                    <div className="sorting">
                      <i className={`bi bi-caret-up-fill asc ${this.state.sorting.asc.includes('email') ? 'active' : ''}`}></i>
                      <i className={`bi bi-caret-down-fill desc ${this.state.sorting.desc.includes('email') ? 'active' : ''}`}></i>
                    </div>
                  </div>
                </th>
                <th onClick={$event => this.handleSorting($event, 'phone')}>
                  <div>
                    Phone
                    <div className="sorting">
                      <i className={`bi bi-caret-up-fill asc ${this.state.sorting.asc.includes('phone') ? 'active' : ''}`}></i>
                      <i className={`bi bi-caret-down-fill desc ${this.state.sorting.desc.includes('phone') ? 'active' : ''}`}></i>
                    </div>
                  </div>
                </th>
                <th onClick={$event => this.handleSorting($event, 'address')}>
                  <div>
                    Address
                    <div className="sorting">
                      <i className={`bi bi-caret-up-fill asc ${this.state.sorting.asc.includes('address') ? 'active' : ''}`}></i>
                      <i className={`bi bi-caret-down-fill desc ${this.state.sorting.desc.includes('address') ? 'active' : ''}`}></i>
                    </div>
                  </div>
                </th>
                <th onClick={$event => this.handleSorting($event, 'cap')}>
                  <div>
                    Cap
                    <div className="sorting">
                      <i className={`bi bi-caret-up-fill asc ${this.state.sorting.asc.includes('cap') ? 'active' : ''}`}></i>
                      <i className={`bi bi-caret-down-fill desc ${this.state.sorting.desc.includes('cap') ? 'active' : ''}`}></i>
                    </div>
                  </div>
                </th>
                <th onClick={$event => this.handleSorting($event, 'city')}>
                  <div>
                    City
                    <div className="sorting">
                      <i className={`bi bi-caret-up-fill asc ${this.state.sorting.asc.includes('city') ? 'active' : ''}`}></i>
                      <i className={`bi bi-caret-down-fill desc ${this.state.sorting.desc.includes('city') ? 'active' : ''}`}></i>
                    </div>
                  </div>
                </th>
                <th onClick={$event => this.handleSorting($event, 'province')}>
                  <div>
                    Province
                    <div className="sorting">
                      <i className={`bi bi-caret-up-fill asc ${this.state.sorting.asc.includes('province') ? 'active' : ''}`}></i>
                      <i className={`bi bi-caret-down-fill desc ${this.state.sorting.desc.includes('province') ? 'active' : ''}`}></i>
                    </div>
                  </div>
                </th>
                <th onClick={$event => this.handleSorting($event, 'state')}>
                  <div>
                    State
                    <div className="sorting">
                      <i className={`bi bi-caret-up-fill asc ${this.state.sorting.asc.includes('state') ? 'active' : ''}`}></i>
                      <i className={`bi bi-caret-down-fill desc ${this.state.sorting.desc.includes('state') ? 'active' : ''}`}></i>
                    </div>
                  </div>
                </th>
              </tr>
            </thead>

            <tbody>
            {Boolean(this.state.users.length) &&
                this.state.users.filter(user => {
                  const { city, province, state } = this.state.filters;

                  if (city !== '' && user.city.toLowerCase().indexOf(city.toLowerCase()) === -1) {
                    return false;
                  }

                  if (province !== '' && user.province.toLowerCase().indexOf(province.toLowerCase()) === -1) {
                    return false;
                  }

                  return !(state !== '' && user.state.toLowerCase().indexOf(state.toLowerCase()) === -1);
                }).map((item, index) => (
                    <tr key={index}>
                      <td>{item.name}</td>
                      <td>{item.surname}</td>
                      <td>{item.username}</td>
                      <td>{item.email}</td>
                      <td>{item.phone}</td>
                      <td>{item.address}</td>
                      <td>{item.cap}</td>
                      <td>{item.city}</td>
                      <td>{item.province}</td>
                      <td>{item.state}</td>
                    </tr>
                ))}
            </tbody>
          </table>
        </main>
      </>
    );
  }
}

export default ComponentName

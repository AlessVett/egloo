# Test React - ITA

Scrivere il contenuto delle seguenti funzioni:

- handleSorting
- handleFiltering

Piena libertà di modificare e/o aggiungere funzioni, modificare la struttura dell'html e possibilità di aggiungere state aggiuntivi.

Non usare librerie esterne.

# Test React - ENG

Write the content of the following functions:

- handleSorting
- handleFiltering

Full freedom to modify and / or add functions, modify the structure of the html and possibility to add additional states.

Do not use external libraries.
